angular.module('myApp', []).controller('personCtrl' , function($scope) {
    $scope.firstname = "John";
    $scope.lastname = "Smith";
    $scope.fullname = function() {
        return $scope.firstname + " " +$scope.lastName;
    };
}).controller('namesCtrl' , function($scope) {
    $scope.names = [
        {name: 'mysql_northwind', description: 'MySQL - NorthWind Example', type: 'Database', database: 'MySQL' , schema: 'northwind'  },
        {name: 'mysql_daf', description: 'MySQL - DAF Physical Model', type: 'Database' , database: 'MySQL' , schema: 'daf'  },
        {name: 'oracle_dmc',  description: 'Oracle - NorthWind Example',  type: 'Database' , database: 'Oracle' , schema: 'dmc'   },
        {name: 'teradata_icdw', description: 'ICDW Data Model', type: 'Database' , database: 'Teradata' , schema: 'ICDW'  },
        {name: 'teradata_icdw', description: 'ICDW Data Model',  type:  'Erwin Import' , database: 'Teradata' , schema: 'ICDW' }
      ];
}).controller('databasesCtrl' , function($scope) {
    $scope.databases = ['MySQL','Teradata', 'Sybase','DB2', 'Microsoft SQL Server', 'Microsoft SQL Server 2005'];
});;


