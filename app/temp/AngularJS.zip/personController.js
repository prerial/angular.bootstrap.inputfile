var app = angular.module('myApp', []);
app.controller('personCtrl' , function($scope) {
    $scope.firstname = "John";
    $scope.lastname = "Smith";
    $scope.fullname = function() {
        return $scope.firstname + " " +$scope.lastName;
    };
});
