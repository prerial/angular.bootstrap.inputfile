var app4 = angular.module('ui.bootstrap.demo' [])
app4.controller('SchemaCtrl', function ($scope) {
  $scope.oneAtATime = true;

  $scope.first = 1;
  $scope.second = 2;
  $scope.username = 'My Name';


  $scope.schemas = [
    {
      title: 'Dynamic Group Header - 1',
      content: 'Dynamic Group Body - 1'
    },
    {
      title: 'Dynamic Group Header - 2',
      content: 'Dynamic Group Body - 2'
    }
  ];

  $scope.items = ['Item 1', 'Item 2', 'Item 3'];

  $scope.addItem = function() {
    var newItemNo = $scope.items.length + 1;
    $scope.items.push('Item ' + newItemNo);
  };

  $scope.status = {
    isCustomHeaderOpen: false,
    isFirstOpen: true,
    isFirstDisabled: false
  };
});

