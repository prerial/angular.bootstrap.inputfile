/**
 * Created by U160964 on 5/16/2017.
 */
(function() {
    "use strict";

    angular.module('app.dmc').component('dashboard', {
        templateUrl: 'dmc/ui/views/dashboardView.html',
        controller: 'DashboardController'

    });
    angular.module('app.dmc').controller('DashboardController', ['$scope', '$location', '$timeout',
        function($scope, $location, $timeout) {
debugger;
            var self = this;
            this.title = 'Dashboard View'
            $scope.formSubmit = function() {
            };

        }]);
})();
