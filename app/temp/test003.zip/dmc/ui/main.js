/**
 * Created by U160964 on 10/9/2017.
 */
angular.module('dmcviews', []);
angular.module('app.dmc', ['ngRoute', 'ngMessages', 'ngAnimate', 'dmcviews'])
    .constant('Urls', {
        'getHeroes':'/data/heroes.json',
        'saveEncryption':'/data/saveEncryptionPolicy.json',
        'getUiGridData':'/data/getUiGridData.json',
        'getAllEncryptions':'/data/getAllEncryptionPolicy.json'
    })
    .constant('Alerts', {
        'encryption':{
            'saveTitle':'New Encryption Policy',
            'getAllTitle':'Get Encryption Policies'
        }
    })
    .config([ '$locationProvider', '$routeProvider',

        function( $locationProvider, $routeProvider) {

            $locationProvider.hashPrefix('');
            $routeProvider
 //               .when('/login', {
 //                   template: '<login-splash></login-splash>'
 //               })
                .when('/dashboard', {
                    template: '<dashboard></dashboard>'
                })
                .when('/heroes', {
                    template: '<heroes-list></heroes-list>'
                })
                .when('/d3index', {
                    template: '<d3index></d3index>'
                })
                .when('/d3ibook/chapter1', {
                    template: '<chapter1-example1></chapter1-example1>'
                })
                .when('d3ibook/chapter1/example1', {
                    template: '<chapter1-example1></chapter1-example1>'
                })




                .when('/uigrid', {
                    template: '<uigrid></uigrid>'
                })
                .when('/animations', {
                    template: '<animations></animations>'
                })
                .when('/ngshowanim', {
                    template: '<ngshowanim></ngshowanim>'
                })
                .when('/ngifanim', {
                    template: '<ngifanim></ngifanim>'
                })
                .when('/firstanim', {
                    template: '<animations></animations>'
                })
                .when('/sourceTypes', {
                    template: '<source-types></source-types>'
                })
                .when('/asyncFunctions', {
                    template: '<async-functions></async-functions>'
                })
                .when('/stringMethods', {
                    template: '<string-methods></string-methods>'
                })
                .when('/sharedMemory', {
                    template: '<shared-memory></shared-memory>'
                })
                .when('/objectEntries', {
                    template: '<object-entries></object-entries>'
                })
                .when('/objectDescriptors', {
                    template: '<object-descriptors></object-descriptors>'
                })
                .when('/trailingCommas', {
                    template: '<trailing-commas></trailing-commas>'
                })
                .when('/', {
                    redirectTo: '/login'
                })

                .otherwise({redirectTo: '/dashboard'});
        }])
    .controller('AppController',['$scope', '$location', function($scope, $location){

        $scope.navid = '0';
        $scope.home = [
            {'label': 'File Upload', 'path': 'login', 'navid': '0'},
            {'label': 'UI Grid', 'path': 'uigrid', 'navid': '0'},
            {'label': 'Animation', 'path':'firstanim', 'navid': '1'},
            {'label': 'Heroes', 'path':'heroes', 'navid': '0'},
            {'label': 'D3 data Visual', 'path':'d3index', 'navid': '2'}
        ];
        $scope.animations = [
            {'label': 'First Anim', 'path':'firstanim', 'navid': '1'},
            {'label': 'ngShow', 'path': 'ngshowanim', 'navid': '1'},
            {'label': 'ngIf', 'path':'ngifanim', 'navid': '1'}
        ];
        $scope.d3 = [
            {'label': 'First', 'path':'d3index', 'navid': '2'}
        ];
        $scope.d3book = [
            {'label': 'Chapter 1', 'path':'d3ibook/chapter1', 'navid': '2'},
            {'label': 'Chapter 2', 'path':'d3ibook/chapter2', 'navid': '2'},
            {'label': 'Chapter 3', 'path':'d3ibook/chapter3', 'navid': '2'},
            {'label': 'Chapter 4', 'path':'d3ibook/chapter4', 'navid': '2'},
            {'label': 'Chapter 5', 'path':'d3ibook/chapter5', 'navid': '2'},
            {'label': 'Chapter 6', 'path':'d3ibook/chapter6', 'navid': '2'}
        ];
        $scope.d3book_chapter1 = [
            {'label': 'Example 1', 'path':'d3ibook/chapter1/example1', 'navid': '2'},
            {'label': 'Example 2', 'path':'d3ibook/chapter1/example2', 'navid': '2'},
            {'label': 'Example 3', 'path':'d3ibook/chapter1/example3', 'navid': '2'},
            {'label': 'Example 4', 'path':'d3ibook/chapter1/example4', 'navid': '2'},
        ];
        $scope.navigation = $scope.home;
        $scope.setNavigation = function(e){
            $scope.navid = $(e.target).attr('navid');
//            debugger
        };
        $scope.$watch('navid', function(newValue, oldValue) {
            if(newValue !== oldValue){
                switch ($scope.navid){
                    case '0':
                        $scope.navigation = $scope.home;
                        break;
                    case '1':
                        $scope.navigation = $scope.animations;
                        break;
                    case '2':
                        $scope.navigation = $scope.d3book;
                        break;

                }
            }
        });

        $scope.isActive = function (viewLocation) {
            var active = (viewLocation === $location.path());
            return active;
        };
        $scope.users = [];
        $scope.$on('$routeChangeStart', function(event, next, current) {
            $scope.$broadcast("clearPopups");

//debugger;
//            console.log(JSON.stringify(next.$$route, null, 4));
//            $.getScript("bundles" + next.$$route.originalPath + "Bundle.js", function(sprm){
//
//           });
        });
    }]);


;angular.module('dmcviews').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('dmc/ui/views/dashboardView.html',
    "<h3>{{$ctrl.title}}</h3><nav><a href=\"#/dashboard\">Dashboard</a></nav><div style=\"top:0;left:0;width:100%;height:100%\"><svg width=\"70\" height=\"215\"><defs><marker id=\"circlearrow\" viewbox=\"0 0 10 10\" refX=\"8\" refY=\"5\" markerUnits=\"strokeWidth\" markerWidth=\"8\" markerHeight=\"5\" orient=\"auto\" style=\"fill: #333\"><path d=\"M0 50 L100 50 M25 25 L 25 75 M75 25 L75 75\"/></marker><marker id=\"ArrowHead\" viewbox=\"0 0 10 10\" refX=\"8\" refY=\"5\" markerUnits=\"strokeWidth\" markerWidth=\"8\" markerHeight=\"5\" orient=\"auto\" style=\"fill: white; stroke: black; stroke-width: 2px\"><path d=\"M50 0 L50 100 M50 50 L25 0 M50 50 L75 0 M25 75 L75 75\"/></marker></defs><g transform=\"translate(20,20)\"/></svg> <svg><div id=\"erDiagram\" class=\"top\" style=\"text-align:left;display: block;margin: auto\"></div><!--<svg width=\"100px\" height=\"100px\">\r" +
    "\n" +
    "\r" +
    "\n" +
    "            <path d=\"M0 50 L100 50 M50 50 L 0 25 M50 50 L0 75 M75 25 L75 75\" stroke=\"red\" fill=\"none\"/></svg>\r" +
    "\n" +
    "    <svg width=\"100px\" height=\"100px\">\r" +
    "\n" +
    "    <path d=\"M0 50 L100 50 M25 25 L 25 75 M75 25 L75 75\" stroke=\"red\" fill=\"none\"/>\r" +
    "\n" +
    "\r" +
    "\n" +
    "    </svg>--><script>$(document).ready(function () {\r" +
    "\n" +
    "                var margin = {top: 20, right: 10, bottom: 20, left: 10};\r" +
    "\n" +
    "                var PointColors = ['lightsteelblue', 'lightgreen']\r" +
    "\n" +
    "                //d3.json(\"erData.json\", function(json) {\r" +
    "\n" +
    "                var erData = [\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    {\r" +
    "\n" +
    "                        \"name\":\"Employees\",\r" +
    "\n" +
    "                        \"columns\":[\r" +
    "\n" +
    "                            {\"name\": \"EmployeeID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                            {\"name\": \"LastName\", \"type\": \"varchar\" , \"size\":20 },\r" +
    "\n" +
    "                            {\"name\": \"FirstName\", \"type\": \"varchar\" , \"size\":10  },\r" +
    "\n" +
    "                            {\"name\": \"Title\", \"type\": \"varchar\" , \"size\":30  },\r" +
    "\n" +
    "                            {\"name\": \"TitleOfCourtesy\", \"type\": \"varchar\" , \"size\":25  },\r" +
    "\n" +
    "                            {\"name\": \"BirthDate\", \"type\": \"datetime\"   },\r" +
    "\n" +
    "                            {\"name\": \"HireDate\", \"type\": \"datetime\"   },\r" +
    "\n" +
    "                            {\"name\": \"Address\", \"type\": \"varchar\" , \"size\":60 },\r" +
    "\n" +
    "                            {\"name\": \"City\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                            {\"name\": \"Region\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                            {\"name\": \"PostalCode\", \"type\": \"varchar\" , \"size\":10  },\r" +
    "\n" +
    "                            {\"name\": \"Country\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                            {\"name\": \"HomePhone\", \"type\": \"varchar\" , \"size\":24 },\r" +
    "\n" +
    "                            {\"name\": \"Extension\", \"type\": \"varchar\" , \"size\":4  },\r" +
    "\n" +
    "                            {\"name\": \"Photo\", \"type\": \"longblob\"  },\r" +
    "\n" +
    "                            {\"name\": \"Notes\", \"type\": \"mediumtext\"  },\r" +
    "\n" +
    "                            {\"name\": \"ReportsTo\", \"type\": \"varchar\" , \"size\":11 },\r" +
    "\n" +
    "                            {\"name\": \"PhotoPath\", \"type\": \"varchar\" , \"size\":255 },\r" +
    "\n" +
    "                            {\"name\": \"Salary\", \"type\": \"float\" }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        ],\r" +
    "\n" +
    "                        \"children\":[\r" +
    "\n" +
    "                            {\r" +
    "\n" +
    "                                \"name\":\"Orders\",\r" +
    "\n" +
    "                                \"columns\":[\r" +
    "\n" +
    "                                    {\"name\": \"OrderID\", \"type\": \"int\" , \"size\":5, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                    {\"name\": \"CustomerID\", \"type\": \"varchar\" , \"size\":5  },\r" +
    "\n" +
    "                                    {\"name\": \"EmployeeID\", \"type\": \"int\" , \"size\":11 },\r" +
    "\n" +
    "                                    {\"name\": \"OrderDate\", \"type\": \"datetime\"  },\r" +
    "\n" +
    "                                    {\"name\": \"RequiredDate\", \"type\": \"datetime\" },\r" +
    "\n" +
    "                                    {\"name\": \"ShippedDate\", \"type\": \"datetime\" },\r" +
    "\n" +
    "                                    {\"name\": \"ShipVia\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                    {\"name\": \"Freight\", \"type\": \"decimal\" , \"size\":\"10,4\" },\r" +
    "\n" +
    "                                    {\"name\": \"ShipName\", \"type\": \"varchar\" , \"size\":40 },\r" +
    "\n" +
    "                                    {\"name\": \"ShipAddress\", \"type\": \"varchar\" , \"size\":60  },\r" +
    "\n" +
    "                                    {\"name\": \"ShipCity\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                    {\"name\": \"ShipRegion\", \"type\": \"varchar\" , \"size\":15},\r" +
    "\n" +
    "                                    {\"name\": \"ShipPostalCode\", \"type\": \"varchar\" , \"size\":10 },\r" +
    "\n" +
    "                                    {\"name\": \"ShipCountry\", \"type\": \"varchar\" , \"size\":15 }\r" +
    "\n" +
    "                                ],\r" +
    "\n" +
    "                                \"children\":[\r" +
    "\n" +
    "                                    {\r" +
    "\n" +
    "                                        \"name\":\"OrderDetails\",\r" +
    "\n" +
    "                                        \"columns\":[\r" +
    "\n" +
    "                                            {\"name\": \"OrderID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                            {\"name\": \"ProductID\", \"type\": \"int\" , \"size\":11 },\r" +
    "\n" +
    "                                            {\"name\": \"UnitPrice\", \"type\": \"decimal\" , \"size\":\"10,4\"},\r" +
    "\n" +
    "                                            {\"name\": \"Quantity\", \"type\": \"smallint\" , \"size\":2 },\r" +
    "\n" +
    "                                            {\"name\": \"Discount\", \"type\": \"double\", \"size\":\"8,0\" }\r" +
    "\n" +
    "                                        ],\r" +
    "\n" +
    "\r" +
    "\n" +
    "                                        \"children\":[\r" +
    "\n" +
    "                                            {\r" +
    "\n" +
    "                                                \"name\":\"Products\",\r" +
    "\n" +
    "                                                \"columns\":[\r" +
    "\n" +
    "                                                    {\"name\": \"ProductID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                    {\"name\": \"ProductName\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                                    {\"name\": \"SupplierID\", \"type\": \"int\" , \"size\":11 },\r" +
    "\n" +
    "                                                    {\"name\": \"CategoryID\", \"type\": \"int\" , \"size\":11  },\r" +
    "\n" +
    "                                                    {\"name\": \"QuantityPerUnit\", \"type\": \"varchar\" , \"size\":20 },\r" +
    "\n" +
    "                                                    {\"name\": \"UnitPrice\", \"type\": \"decimal\" , \"size\":\"10,4\"},\r" +
    "\n" +
    "                                                    {\"name\": \"UnitsInStock\", \"type\": \"smallint\" , \"size\":2 },\r" +
    "\n" +
    "                                                    {\"name\": \"UnitsOnOrder\", \"type\": \"smallint\" , \"size\":2  },\r" +
    "\n" +
    "                                                    {\"name\": \"ReorderLevel\", \"type\": \"smallint\" , \"size\":2 },\r" +
    "\n" +
    "                                                    {\"name\": \"Discontinued\", \"type\": \"bit\", \"size\":1 }\r" +
    "\n" +
    "                                                ],\r" +
    "\n" +
    "                                                \"children\":[\r" +
    "\n" +
    "                                                    {\r" +
    "\n" +
    "                                                        \"name\":\"Suppliers\",\r" +
    "\n" +
    "                                                        \"columns\":[\r" +
    "\n" +
    "                                                            {\"name\": \"SupplierID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                            {\"name\": \"CompanyName\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                                            {\"name\": \"ContactName\", \"type\": \"varchar\" , \"size\":30 },\r" +
    "\n" +
    "                                                            {\"name\": \"ContactTitle\", \"type\": \"varchar\" , \"size\":30  },\r" +
    "\n" +
    "                                                            {\"name\": \"Address\", \"type\": \"varchar\" , \"size\":60 },\r" +
    "\n" +
    "                                                            {\"name\": \"City\", \"type\": \"varchar\" , \"size\":15},\r" +
    "\n" +
    "                                                            {\"name\": \"Region\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                                                            {\"name\": \"PostalCode\", \"type\": \"varchar\" , \"size\":10 },\r" +
    "\n" +
    "                                                            {\"name\": \"Country\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                                            {\"name\": \"Phone\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                            {\"name\": \"Fax\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                            {\"name\": \"HomePage\", \"type\": \"mediumtext\"  }\r" +
    "\n" +
    "                                                        ],\r" +
    "\n" +
    "\r" +
    "\n" +
    "                                                    },\r" +
    "\n" +
    "                                                    {\r" +
    "\n" +
    "                                                        \"name\":\"CustomerDemo\",\r" +
    "\n" +
    "                                                        \"columns\":[\r" +
    "\n" +
    "                                                            {\"name\": \"SupplierID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                            {\"name\": \"CompanyName\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                                            {\"name\": \"ContactName\", \"type\": \"varchar\" , \"size\":30 },\r" +
    "\n" +
    "                                                            {\"name\": \"ContactTitle\", \"type\": \"varchar\" , \"size\":30  },\r" +
    "\n" +
    "                                                            {\"name\": \"Address\", \"type\": \"varchar\" , \"size\":60 },\r" +
    "\n" +
    "                                                            {\"name\": \"City\", \"type\": \"varchar\" , \"size\":15},\r" +
    "\n" +
    "                                                            {\"name\": \"Region\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                                                            {\"name\": \"PostalCode\", \"type\": \"varchar\" , \"size\":10 },\r" +
    "\n" +
    "                                                            {\"name\": \"Country\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                                            {\"name\": \"Phone\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                            {\"name\": \"Fax\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                            {\"name\": \"HomePage\", \"type\": \"mediumtext\"  }\r" +
    "\n" +
    "                                                        ]}\r" +
    "\n" +
    "                                                ]\r" +
    "\n" +
    "                                            }]\r" +
    "\n" +
    "                                    }\r" +
    "\n" +
    "                                    ,\r" +
    "\n" +
    "                                    {\r" +
    "\n" +
    "                                        \"name\":\"Customers\",\r" +
    "\n" +
    "                                        \"columns\":[\r" +
    "\n" +
    "                                            {\"name\": \"OrderID\", \"type\": \"int\" , \"size\":5, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                            {\"name\": \"CustomerID\", \"type\": \"varchar\" , \"size\":5  },\r" +
    "\n" +
    "                                            {\"name\": \"EmployeeID\", \"type\": \"int\" , \"size\":11 },\r" +
    "\n" +
    "                                            {\"name\": \"OrderDate\", \"type\": \"datetime\"  },\r" +
    "\n" +
    "                                            {\"name\": \"RequiredDate\", \"type\": \"datetime\" },\r" +
    "\n" +
    "                                            {\"name\": \"ShippedDate\", \"type\": \"datetime\" },\r" +
    "\n" +
    "                                            {\"name\": \"ShipVia\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                            {\"name\": \"Freight\", \"type\": \"decimal\" , \"size\":\"10,4\" },\r" +
    "\n" +
    "                                            {\"name\": \"ShipName\", \"type\": \"varchar\" , \"size\":40 },\r" +
    "\n" +
    "                                            {\"name\": \"ShipAddress\", \"type\": \"varchar\" , \"size\":60  },\r" +
    "\n" +
    "                                            {\"name\": \"ShipCity\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                            {\"name\": \"ShipRegion\", \"type\": \"varchar\" , \"size\":15},\r" +
    "\n" +
    "                                            {\"name\": \"PostalCode\", \"type\": \"varchar\" , \"size\":10 },\r" +
    "\n" +
    "                                            {\"name\": \"ShipCountry\", \"type\": \"varchar\" , \"size\":15 }\r" +
    "\n" +
    "                                        ],\r" +
    "\n" +
    "                                        \"children\":[\r" +
    "\n" +
    "                                            {\r" +
    "\n" +
    "                                                \"name\":\"CustomerDemo\",\r" +
    "\n" +
    "                                                \"columns\":[\r" +
    "\n" +
    "                                                    {\"name\": \"SupplierID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                    {\"name\": \"CompanyName\", \"type\": \"varchar\" , \"size\":40  },\r" +
    "\n" +
    "                                                    {\"name\": \"ContactName\", \"type\": \"varchar\" , \"size\":30 },\r" +
    "\n" +
    "                                                    {\"name\": \"ContactTitle\", \"type\": \"varchar\" , \"size\":30  },\r" +
    "\n" +
    "                                                    {\"name\": \"Address\", \"type\": \"varchar\" , \"size\":60 },\r" +
    "\n" +
    "                                                    {\"name\": \"City\", \"type\": \"varchar\" , \"size\":15},\r" +
    "\n" +
    "                                                    {\"name\": \"Region\", \"type\": \"varchar\" , \"size\":15  },\r" +
    "\n" +
    "                                                    {\"name\": \"PostalCode\", \"type\": \"varchar\" , \"size\":10 },\r" +
    "\n" +
    "                                                    {\"name\": \"Country\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                                    {\"name\": \"Phone\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                    {\"name\": \"Fax\", \"type\": \"varchar\" , \"size\":24},\r" +
    "\n" +
    "                                                    {\"name\": \"HomePage\", \"type\": \"mediumtext\"  }\r" +
    "\n" +
    "                                                ],\r" +
    "\n" +
    "                                                \"children\":[\r" +
    "\n" +
    "                                                    {\r" +
    "\n" +
    "                                                        \"name\":\"Demographics\",\r" +
    "\n" +
    "                                                        \"columns\":[\r" +
    "\n" +
    "                                                            {\"name\": \"CategoryID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                            {\"name\": \"CategoryName\", \"type\": \"varchar\" , \"size\":15 },\r" +
    "\n" +
    "                                                            {\"name\": \"Description\", \"type\": \"mediumtext\" },\r" +
    "\n" +
    "                                                            {\"name\": \"Picture\", \"type\": \"longblob\"}\r" +
    "\n" +
    "                                                        ],\r" +
    "\n" +
    "\r" +
    "\n" +
    "                                                    }\r" +
    "\n" +
    "                                                ]\r" +
    "\n" +
    "                                            }\r" +
    "\n" +
    "                                        ]\r" +
    "\n" +
    "                                    }\r" +
    "\n" +
    "                                ]},\r" +
    "\n" +
    "                            {\r" +
    "\n" +
    "                                \"name\":\"EmployeeTerritories\",\r" +
    "\n" +
    "                                \"columns\":[\r" +
    "\n" +
    "                                    {\"name\": \"EmployeeID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                    {\"name\": \"TerritoryID\", \"type\": \"varchar\" , \"size\":20,  \"primaryKey\":\"true\",  \"required\":\"true\"   }\r" +
    "\n" +
    "                                ],\r" +
    "\n" +
    "                                \"children\":[\r" +
    "\n" +
    "                                    {\r" +
    "\n" +
    "                                        \"name\":\"Territories\",\r" +
    "\n" +
    "                                        \"columns\":[\r" +
    "\n" +
    "                                            {\"name\": \"TerritoryID\", \"type\": \"varchar\" , \"size\":20, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                            {\"name\": \"Description\", \"type\": \"varchar\" , \"size\":50  },\r" +
    "\n" +
    "                                            {\"name\": \"RegionID\", \"type\": \"int\" , \"size\":11 }\r" +
    "\n" +
    "                                        ],\r" +
    "\n" +
    "                                        \"children\":[\r" +
    "\n" +
    "                                            {\r" +
    "\n" +
    "                                                \"name\":\"Region\",\r" +
    "\n" +
    "                                                \"columns\":[\r" +
    "\n" +
    "                                                    {\"name\": \"RegionID\", \"type\": \"int\" , \"size\":11, \"primaryKey\":\"true\",  \"required\":\"true\" },\r" +
    "\n" +
    "                                                    {\"name\": \"RegionDescription\", \"type\": \"varchar\" , \"size\":50  }\r" +
    "\n" +
    "                                                ],\r" +
    "\n" +
    "\r" +
    "\n" +
    "                                            }\r" +
    "\n" +
    "                                        ]\r" +
    "\n" +
    "                                    }\r" +
    "\n" +
    "                                ]\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "                        ]\r" +
    "\n" +
    "                    }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                ];\r" +
    "\n" +
    "\r" +
    "\n" +
    "                var w = 1800,\r" +
    "\n" +
    "                    h = 1900,\r" +
    "\n" +
    "//            var w = 1200,\r" +
    "\n" +
    "//                h = 1300,\r" +
    "\n" +
    "                    i = 0,\r" +
    "\n" +
    "                    duration = 500,\r" +
    "\n" +
    "                    root;\r" +
    "\n" +
    "\r" +
    "\n" +
    "                var tree = d3.layout.tree()\r" +
    "\n" +
    "                    .size([h, w - 160]);\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                var diagonal = d3.svg.diagonal()\r" +
    "\n" +
    "                    .source(function (d) {\r" +
    "\n" +
    "                        return {\r" +
    "\n" +
    "                            \"x\": d.source.x + d.source.height/2 ,\r" +
    "\n" +
    "                            \"y\": d.source.y +150\r" +
    "\n" +
    "                        };\r" +
    "\n" +
    "                    })\r" +
    "\n" +
    "                    .target(function (d) {\r" +
    "\n" +
    "                        return {\r" +
    "\n" +
    "                            \"x\": d.target.x + d.target.height/2,\r" +
    "\n" +
    "                            \"y\": d.target.y+100\r" +
    "\n" +
    "                        };\r" +
    "\n" +
    "                    })\r" +
    "\n" +
    "                    .projection(function (d) { return [d.x+15, d.y-30 ];\r" +
    "\n" +
    "                    });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                function pan(domNode, direction) {\r" +
    "\n" +
    "                    var speed = panSpeed;\r" +
    "\n" +
    "                    if (panTimer) {\r" +
    "\n" +
    "                        clearTimeout(panTimer);\r" +
    "\n" +
    "                        translateCoords = d3.transform(svgGroup.attr(\"transform\"));\r" +
    "\n" +
    "                        if (direction == 'left' || direction == 'right') {\r" +
    "\n" +
    "                            translateX = direction == 'left' ? translateCoords.translate[0] + speed : translateCoords.translate[0] - speed;\r" +
    "\n" +
    "                            translateY = translateCoords.translate[1];\r" +
    "\n" +
    "                        } else if (direction == 'up' || direction == 'down') {\r" +
    "\n" +
    "                            translateX = translateCoords.translate[0];\r" +
    "\n" +
    "                            translateY = direction == 'up' ? translateCoords.translate[1] + speed : translateCoords.translate[1] - speed;\r" +
    "\n" +
    "                        }\r" +
    "\n" +
    "                        scaleX = translateCoords.scale[0];\r" +
    "\n" +
    "                        scaleY = translateCoords.scale[1];\r" +
    "\n" +
    "                        scale = zoomListener.scale();\r" +
    "\n" +
    "                        svgGroup.transition().attr(\"transform\", \"translate(\" + translateX + \",\" + translateY + \")scale(\" + scale + \")\");\r" +
    "\n" +
    "                        d3.select(domNode).select('g.node').attr(\"transform\", \"translate(\" + translateX + \",\" + translateY + \")\");\r" +
    "\n" +
    "                        zoomListener.scale(zoomListener.scale());\r" +
    "\n" +
    "                        zoomListener.translate([translateX, translateY]);\r" +
    "\n" +
    "                        panTimer = setTimeout(function() {\r" +
    "\n" +
    "                            pan(domNode, speed, direction);\r" +
    "\n" +
    "                        }, 50);\r" +
    "\n" +
    "                    }\r" +
    "\n" +
    "                }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                // Define the zoom function for the zoomable tree\r" +
    "\n" +
    "\r" +
    "\n" +
    "                function zoom() {\r" +
    "\n" +
    "                    svgGroup.attr(\"transform\", \"translate(\" + d3.event.translate + \")scale(\" + d3.event.scale + \")\");\r" +
    "\n" +
    "                }\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                // define the zoomListener which calls the zoom function on the \"zoom\" event constrained within the scaleExtents\r" +
    "\n" +
    "                var zoomListener = d3.behavior.zoom().scaleExtent([0.1, 3]).on(\"zoom\", zoom);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                var vis = d3.select('#erDiagram').append(\"svg:svg\")\r" +
    "\n" +
    "                    .attr(\"width\", w)\r" +
    "\n" +
    "                    .attr(\"height\", h)\r" +
    "\n" +
    "                    .attr(\"transform\", \"translate(0,0)\")\r" +
    "\n" +
    "                    .call(zoomListener);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                var svgGroup = vis.append(\"g\");\r" +
    "\n" +
    "                root = erData[0];\r" +
    "\n" +
    "                root.x0 = h / 2;\r" +
    "\n" +
    "                root.y0 = 0;\r" +
    "\n" +
    "                update(root);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                function update(source) {\r" +
    "\n" +
    "                    var nodes = tree.nodes(root).reverse();\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    var node = svgGroup.selectAll(\"g.node\")\r" +
    "\n" +
    "                        .data(nodes, function (d) {\r" +
    "\n" +
    "                            return d.id || (d.id = ++i);\r" +
    "\n" +
    "                        });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    var nodeEnter = node.enter().append(\"g\")\r" +
    "\n" +
    "                        .attr(\"class\", \"node\")\r" +
    "\n" +
    "                        .attr(\"transform\", function (d) {\r" +
    "\n" +
    "                            return \"translate(\" + source.x0 + \",\" + source.y0 + \")\";\r" +
    "\n" +
    "                        });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    nodeEnter.append(\"svg:rect\")\r" +
    "\n" +
    "                        .attr(\"width\", 150)\r" +
    "\n" +
    "                        .attr(\"height\", 500)\r" +
    "\n" +
    "                        .attr('y', 0)\r" +
    "\n" +
    "                        .attr('rx', 5)\r" +
    "\n" +
    "                        .attr('ry', 5)\r" +
    "\n" +
    "                        .attr('stroke', 'black')\r" +
    "\n" +
    "                        .attr('stroke-width', '3px')\r" +
    "\n" +
    "                        .attr('fill', 'white')\r" +
    "\n" +
    "                        .attr(\"id\", function (d) {\r" +
    "\n" +
    "                            return d._children;\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .style(\"fill\", function (d) {\r" +
    "\n" +
    "                            return d._children ? \"white\" : \"white\";\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        // .on(\"click\", click);\r" +
    "\n" +
    "                        .on(\"click\", function(){\r" +
    "\n" +
    "                            PointColors = [PointColors[1], PointColors[0]]\r" +
    "\n" +
    "                            d3.select(this).style(\"fill\", PointColors[0]);})\r" +
    "\n" +
    "                        .on({\r" +
    "\n" +
    "                            \"mouseover\": function(d) {\r" +
    "\n" +
    "                                d3.select(this).style(\"cursor\", \"pointer\");\r" +
    "\n" +
    "                            },\r" +
    "\n" +
    "                            \"mouseout\": function(d) {\r" +
    "\n" +
    "                                d3.select(this).style(\"cursor\", \"default\");\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    nodeEnter.append(\"text\")\r" +
    "\n" +
    "                        .attr(\"x\", function (d) {\r" +
    "\n" +
    "                            return d._children ? -8 : 8;\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .attr(\"y\", 3)\r" +
    "\n" +
    "                        .attr(\"dy\", \"0.68em\")\r" +
    "\n" +
    "                        .text(function (d) {\r" +
    "\n" +
    "                            return d.name;\r" +
    "\n" +
    "                        });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    wrap(d3.selectAll('text'), 150);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    nodeEnter.transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"transform\", function (d) {\r" +
    "\n" +
    "                            return \"translate(\" + (d.x-50) + \",\" + (d.y+50) + \")\";\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .style(\"opacity\", 1)\r" +
    "\n" +
    "                        .select(\"rect\")\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        .style(\"fill\", \"lightsteelblue\");\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    node.transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"transform\", function (d) {\r" +
    "\n" +
    "                            return \"translate(\" + (d.x-50) + \",\" + (d.y+50) + \")\";\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .style(\"opacity\", 1);\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    node.exit().transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"transform\", function (d) {\r" +
    "\n" +
    "                            return \"translate(\" + source.y + \",\" + source.x + \")\";\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .style(\"opacity\", 1e-6)\r" +
    "\n" +
    "                        .remove();\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    var link = svgGroup.selectAll(\"path.link\")\r" +
    "\n" +
    "                        .data(tree.links(nodes), function (d) {\r" +
    "\n" +
    "                            return d.target.id;\r" +
    "\n" +
    "                        });\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    svgGroup.selectAll(\"path.link\").attr()\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    link.enter().insert(\"svg:path\", \"g\")\r" +
    "\n" +
    "                        .attr(\"class\",  function (d) {\r" +
    "\n" +
    "                            if(d.source == root)\r" +
    "\n" +
    "                            {\r" +
    "\n" +
    "                                return \"link_dashed\" ;\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "                            else\r" +
    "\n" +
    "                            {\r" +
    "\n" +
    "                                return \"link_continuous\" ;\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .attr(\"marker-mid\",\"ArrowHead\")\r" +
    "\n" +
    "                        //return (d.source != root) ? \"link_dashed\" : \"link_continuous\" ; })\r" +
    "\n" +
    "                        .attr(\"d\", function (d) {\r" +
    "\n" +
    "                            var o = {\r" +
    "\n" +
    "                                x: source.x0,\r" +
    "\n" +
    "                                y: source.y0,\r" +
    "\n" +
    "                                height: source.height\r" +
    "\n" +
    "                            };\r" +
    "\n" +
    "                            return diagonal({\r" +
    "\n" +
    "                                source: o,\r" +
    "\n" +
    "                                target: o\r" +
    "\n" +
    "                            });\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        .transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"d\", diagonal);\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    link.transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"d\", diagonal);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    link.exit().transition()\r" +
    "\n" +
    "                        .duration(duration)\r" +
    "\n" +
    "                        .attr(\"d\", function (d) {\r" +
    "\n" +
    "                            var o = {\r" +
    "\n" +
    "                                x: source.x,\r" +
    "\n" +
    "                                y: source.y\r" +
    "\n" +
    "                            };\r" +
    "\n" +
    "                            return diagonal({\r" +
    "\n" +
    "                                source: o,\r" +
    "\n" +
    "                                target: o\r" +
    "\n" +
    "                            });\r" +
    "\n" +
    "                        })\r" +
    "\n" +
    "                        .remove();\r" +
    "\n" +
    "\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    nodes.forEach(function (d) {\r" +
    "\n" +
    "                        d.x0 = d.x;\r" +
    "\n" +
    "                        d.y0 = d.y;\r" +
    "\n" +
    "                    });\r" +
    "\n" +
    "                }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                function click(d) {\r" +
    "\n" +
    "                    if (d.children) {\r" +
    "\n" +
    "                        d._children = d.children;\r" +
    "\n" +
    "                        d.children = null;\r" +
    "\n" +
    "                    } else {\r" +
    "\n" +
    "                        d.children = d._children;\r" +
    "\n" +
    "                        d._children = null;\r" +
    "\n" +
    "                    }\r" +
    "\n" +
    "                    update(d);\r" +
    "\n" +
    "                }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                function wrap(text, width) {\r" +
    "\n" +
    "                    text.each(function (d) {\r" +
    "\n" +
    "                        var text = d3.select(this),\r" +
    "\n" +
    "\r" +
    "\n" +
    "                            words = d.name.split(/\\s+/).reverse(),\r" +
    "\n" +
    "                            word,\r" +
    "\n" +
    "                            line = [],\r" +
    "\n" +
    "                            lineNumber = 0,\r" +
    "\n" +
    "                            lineHeight = 1.1,\r" +
    "\n" +
    "                            y = text.attr(\"y\"),\r" +
    "\n" +
    "                            dy = parseFloat(text.attr(\"dy\")),\r" +
    "\n" +
    "                            tspan = text.text(null).append(\"tspan\").attr(\"x\", 0).attr(\"y\", y).attr(\"dy\", dy + \"em\").attr('font-weight', 'bold').attr('fill','blue');\r" +
    "\n" +
    "                        while (word = words.pop()) {\r" +
    "\n" +
    "                            line.push(word);\r" +
    "\n" +
    "                            tspan.text(line.join(\" \"));\r" +
    "\n" +
    "                            if (tspan.node().getComputedTextLength() > width) {\r" +
    "\n" +
    "                                line.pop();\r" +
    "\n" +
    "                                tspan.text(line.join(\" \"));\r" +
    "\n" +
    "                                line = [word];\r" +
    "\n" +
    "                                tspan = text.append(\"tspan\").attr(\"x\", 0).attr(\"y\", y).attr(\"dy\", ++lineNumber * lineHeight + dy + \"em\").text(word);\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                            if(d.columns){\r" +
    "\n" +
    "                                d.columns.forEach(function(c,i){\r" +
    "\n" +
    "                                    dy = dy + 1;\r" +
    "\n" +
    "                                    tspan = text.append(\"tspan\").attr(\"x\", 0).attr(\"y\", y).attr(\"dy\", dy + \"em\").text(c.name);\r" +
    "\n" +
    "                                });\r" +
    "\n" +
    "                            }\r" +
    "\n" +
    "                        }\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        var textBox = text.node().getBBox();\r" +
    "\n" +
    "\r" +
    "\n" +
    "                        d.height = 19 * (lineNumber + 1);\r" +
    "\n" +
    "                        d3.select(this.parentNode.children[0]).attr('height', textBox.height);\r" +
    "\n" +
    "\r" +
    "\n" +
    "                    });\r" +
    "\n" +
    "                }\r" +
    "\n" +
    "\r" +
    "\n" +
    "            });</script></svg></div>"
  );

}]);
;/**
 * Created by U160964 on 5/16/2017.
 */
(function() {
    "use strict";

    angular.module('app.dmc').component('dashboard', {
        templateUrl: 'dmc/ui/views/dashboardView.html',
        controller: 'DashboardController'

    });
    angular.module('app.dmc').controller('DashboardController', ['$scope', '$location', '$timeout',
        function($scope, $location, $timeout) {
debugger;
            var self = this;
            this.title = 'Dashboard View'
            $scope.formSubmit = function() {
            };

        }]);
})();
